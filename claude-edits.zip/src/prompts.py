SPELLCHECK_INSTRUCTIONS = """
You are a {language} language expert specializing in correcting misspelled words in open-ended survey responses.

Survey Question:
"{var_lab}"

Your task is to correct responses that contain placeholder tokens indicating spelling mistakes.

For each task:
- Replace every <oov_word> placeholder with the best possible correction of the corresponding misspelled word, taking into account the meaning and context of the survey question.
- If a better correction exists than the ones provided, prefer that.
- You may split a misspelled word into two words **only if** the split preserves the intended meaning and fits grammatically.
- If no suitable correction is possible, return "[NO RESPONSE]" as the corrected sentence for that task.

You will receive for each task:
- A sentence containing one or more <oov_word> placeholders.
- A list of misspelled words, in the same order as the placeholders.
- A list of suggested corrections, in the same order.

Below are the tasks to process:
{tasks}

REQUIRED OUTPUT FORMAT:
You must return a JSON object with a single key "corrections", whose value is an array of objects.
Each object in the "corrections" array must have exactly these fields:
- "respondent_id": "ID_FROM_TASK"
- "corrected_response": "The fully corrected response"
"""

GRADER_INSTRUCTIONS = """
You are a {language} grader evaluating open-ended survey responses.
Your task is to determine whether each response is **meaningless**.

A response should be considered **meaningless** only if:
- It only expresses uncertainty or lack of knowledge (e.g., “I don’t know”, “N/A”, “Not applicable”).
- It simply repeats the question without adding any new content.
- It consists of random characters, gibberish, or filler text with no semantic meaning (e.g., “asdfkj”, “lorem ipsum”).

### Survey question:
"{var_lab}"

### Responses to evaluate:
{responses}

### REQUIRED OUTPUT FORMAT:
Return a **JSON array**. Each object in the array must contain exactly:
- `"respondent_id"`: (string or number) The respondent's ID
- `"response"`: (string) The exact response text
- `"quality_filter"`: (boolean) `true` if the response is meaningless, `false` otherwise
"""

SEGMENTATION_PROMPT = """
You are a helpful {language} expert in analyzing survey responses. Your task is to segment free-text responses into distinct, standalone ideas.

# Survey Question Context
The responses you'll analyze were given to this question: "{var_lab}"

# Your Task
Break each response into the smallest meaningful standalone units, where each segment represents EXACTLY ONE:
- Opinion
- Preference
- Issue
- Topic
- Idea

# Segmentation Rules
1. Split at conjunctions (and, or, but, also) when they connect DIFFERENT ideas or topics
2. Split listed items into separate segments (e.g., "milk and sugar" → "milk", "sugar")
3. When items share context, preserve that context in each segment:
   Example: "I like milk and sugar in my coffee" →
   - "I like milk in my coffee"
   - "I like sugar in my coffee"
4. Use the respondent's exact words - do not paraphrase or correct
5. Keep meaningless responses (e.g., "Don't know", "?") as a single segment

# Output Format
Return a JSON array with these fields for each segment:
- "segment_id": A sequential number as string ("1", "2", etc.)
- "segment_response": The exact segmented text with necessary context preserved

# Response to segment:
{response}
"""

REFINEMENT_PROMPT = """
You are a {language} expert in semantic segmentation of survey responses.

# Task Overview
Review and refine segments from responses to this survey question: "{var_lab}"

# Your Specific Goals
1. Ensure each segment contains ONLY ONE standalone idea or item
2. Split any segment that still contains multiple distinct ideas or items
3. Preserve necessary context when splitting compound statements

# Refinement Rules
- Split segments that contain multiple distinct items (connected by conjunctions like "and", "or")
- When splitting, duplicate any necessary context to make each segment meaningful:
  * For example: "I like milk and sugar in my coffee" should become two segments:
    - "I like milk in my coffee"
    - "I like sugar in my coffee"
- Only duplicate words that appear in the original response
- Never merge segments
- Keep meaningless responses intact (e.g., "Don't know")

# Examples
## Example 1: Multiple ideas with shared context
Input: {{"segment_id": "1", "segment_response": "I like milk and sugar in my coffee"}}
Output: [
  {{"segment_id": "1", "segment_response": "I like milk in my coffee"}},
  {{"segment_id": "2", "segment_response": "I like sugar in my coffee"}}
]

## Example 2: Multiple ideas without shared context
Input: {{"segment_id": "1", "segment_response": "The price is too high and the quality is low"}}
Output: [
  {{"segment_id": "1", "segment_response": "The price is too high"}},
  {{"segment_id": "2", "segment_response": "the quality is low"}}
]

# Segments to refine:
{segments}

# Output Format
Return a JSON array with these fields for each refined segment:
- "segment_id": A sequential number as string ("1", "2", etc.)
- "segment_response": The properly segmented text using ONLY words from the original response
"""

CODING_PROMPT = """
You are a {language} expert in thematic analysis of survey responses.

# Task Overview
Code each segment from responses to this survey question: "{var_lab}"

Each segment is a standalone sentence or clause extracted from a full response.

# For Each Segment, You Will:
1. Keep the original segment_id and segment_response
2. Add a descriptive_code (a thematic label)
3. Add a code_description (a clarification of the label)

# Field Requirements

## descriptive_code
- A concise label of up to 5 words total, using ONLY ADJECTIVES AND NOUNS in {language}, that captures the CENTRAL MEANING of the segment
- ONLY return labels that reflect ONE idea, topic, concern, issue, or theme in response to the question: "{var_lab}"
- NEVER return multi-headed labels or combinations of multiple ideas
- Format: ALL_CAPS_WITH_UNDERSCORES
- Examples: "PRODUCT_QUALITY", "MORE_OPTIONS", "UNNECESSARY_COMPLEXITY"
- Language: {language}


## code_description
- Rewrite the segment as a natural-sounding **first-person response** to the question: "{var_lab}"
- Make sure it sounds like something a person would actually say when answering the question
- Use a direct, conversational or instructional tone:
  - If the segment is a suggestion: use an imperative tone (e.g., "Maak...", "Laat...")
  - If the segment expresses a wish or opinion: use first-person (e.g., "Ik wil...", "Ik vind...")
- NEVER rephrase the segment as a third-person summary (e.g., "Wil dat de inhoud...") — that does not sound like a response
- Do NOT add interpretations beyond what's in the original segment
- Language: {language}

# Special Cases
For meaningless responses (e.g., "?", "Don't know"):
- descriptive_code: "NA"
- code_description: "NA"

# Segments to code:
{segments}

# Output Format
Return a valid JSON array with these fields for each segment:
- "segment_id": The original segment ID
- "segment_response": The original segment text
- "descriptive_code": Your thematic label in ALL_CAPS_WITH_UNDERSCORES
- "code_description": Your clarifying description

Ensure all output is written in {language}, unless the code is "NA".
"""

MERGE_PROMPT = """
RESEARCH QUESTION: "{var_lab}"

You are evaluating whether clusters of survey responses represent meaningfully different answers to the research question above.

## Your Decision Task:
Determine whether each pair of clusters should be merged based on how they address the research question. 

The key question for each comparison is:
"Do these clusters represent meaningfully different responses to the research question, or are they essentially saying the same thing?"

Language: {language}

## Decision Criteria:

### YES (merge) ONLY IF:
- Both clusters express essentially the same sentiment, concern, suggestion, or perspective
- The differences between them are minimal or irrelevant to the research question
- A survey analyst would reasonably group these responses together as the same type of answer

### NO (don't merge) IF:
- The clusters represent distinct viewpoints, suggestions, or concerns
- They focus on different aspects of the research question
- They provide unique or complementary information
- They represent different topics even within the same broad theme
- There is ANY meaningful differentiation relevant to understanding survey responses

## Important Guidelines:
- Focus SPECIFICALLY on the research question context
- Base decisions on the MOST REPRESENTATIVE responses in each cluster (shown by cosine similarity to centroid)
- Be conservative - when in doubt, keep clusters separate
- Consider semantic meaning, not just surface-level wording

{cluster_pairs}

REQUIRED OUTPUT FORMAT:
Return a JSON object with a single key "decisions", containing an array of objects with these fields:
- "cluster_id_1": First cluster ID
- "cluster_id_2": Second cluster ID  
- "should_merge": Boolean (true ONLY if clusters are not meaningfully differentiated)
- "reason": Brief explanation of your decision (1-2 sentences maximum)
"""

INITIAL_LABEL_PROMPT = """
You are a {language} expert in labeling micro-clusters of survey responses to this research question:
"{var_lab}"

Each cluster contains representative response segments that express a distinct idea or perspective related to the research question.

TASK:
- Assign a precise and unique label to each cluster, and identify the core concepts that justify the label.

LABELING RULES:
- Focus on the underlying meaning, not surface wording
- Labels should be specific, non-generic, and clearly differentiated
- Use 2–6 words for each label
- Avoid vague terms like "miscellaneous" or "general concerns"
- Mark clusters as "off-topic" if they do not contribute meaningfully to answering the research question

OUTPUT FORMAT:
Return a JSON object with the following structure:

{
"labels": [
{
"cluster_id": "38",
"label": "Portie grootte vergroten",
"keywords": ["portie", "groter", "meer", "hoeveelheid"],
"confidence": 0.94
},
{
"cluster_id": "12", 
"label": "Verse ingrediënten gebruiken",
"keywords": ["vers", "ingrediënten", "kwaliteit", "natuurlijk"],
"confidence": 0.89
}
]
}

Language: {language}

Input clusters:
{clusters}
"""


TOPIC_CREATION_PROMPT = """
You are a {language} expert organizing survey responses about ready-made meals (kant-en-klaar maaltijden).
Research question: "{var_lab}"

TASK: Group micro-clusters into 15-20 SPECIFIC topics (Level 2 nodes).

CRITICAL RULES:
1. Create AT LEAST 15 distinct topics from the clusters
2. Each topic should be SPECIFIC and ACTIONABLE
3. NO topic should contain more than 8% of total responses
4. Absolutely NO generic catch-all topics like "Overige aspecten" or "Algemene kwaliteit"
5. Topics must be mutually exclusive

GOOD TOPIC EXAMPLES:
✓ "Zoutgehalte verminderen" (specific nutritional aspect)
✓ "Verpakking verduurzamen" (specific sustainability aspect)  
✓ "Bereidingsinstructies verduidelijken" (specific usability aspect)
✓ "Vegetarische opties uitbreiden" (specific product range aspect)
✓ "Portiegrootte voor één persoon" (specific size aspect)

BAD TOPIC EXAMPLES:
✗ "Algemene kwaliteitsverbetering" (too vague)
✗ "Overige wensen" (catch-all category)
✗ "Gezondheid en voeding" (too broad - split into salt, sugar, fat, etc.)
✗ "Product samenstelling" (too broad - split into specific aspects)

OUTPUT FORMAT:
{
"topics": [
{
"label": "Zoutgehalte verminderen",
"cluster_ids": ["4", "15", "22"],
"explanation": "Clusters specifically about reducing salt content in meals"
},
{
"label": "Vegetarische varianten uitbreiden", 
"cluster_ids": ["12", "29"],
"explanation": "Clusters about adding more vegetarian meal options"
}
// ... AT LEAST 15 topics total ...
],
"cluster_to_topic_mapping": {
"4": "Zoutgehalte verminderen",
"15": "Zoutgehalte verminderen",
// ... mapping for ALL clusters ...
}
}

Language: {language}

Input cluster labels:
{clusters}
"""

THEME_CREATION_PROMPT = """
You are a {language} expert grouping topics into HIGH-LEVEL THEMES for research question:
"{var_lab}"

TASK: Group the 15-20 topics into 5-8 THEMES (Level 1 nodes).

CRITICAL RULES:
1. Create exactly 5-8 themes total
2. Each theme MUST contain at least 2 topics (no single-topic themes!)
3. NO theme should contain more than 25% of all topics
4. NO generic themes like "Overige" - redistribute those topics to relevant themes
5. Themes should represent major dimensions of consumer concerns

GOOD THEME EXAMPLES:
✓ "Nutritionele samenstelling" (groups: salt reduction, sugar reduction, fat content, additives)
✓ "Duurzaamheid en milieu" (groups: packaging, local sourcing, waste reduction)
✓ "Product diversiteit" (groups: vegetarian options, portion sizes, cuisine variety)
✓ "Gebruiksgemak" (groups: preparation time, instructions, shelf life)

BAD THEME EXAMPLES:
✗ "Algemene verbeteringen" (too vague)
✗ "Overige aspecten" (catch-all - redistribute!)
✗ "Kwaliteit" (too broad - be specific about which quality aspects)

REQUIRED STRUCTURE:
- 5-8 themes total
- Each theme has 2-5 topics
- Clear conceptual boundaries between themes
- Together they cover ALL major consumer concerns

OUTPUT FORMAT:
{
"themes": [
{
"label": "Nutritionele samenstelling",
"topic_labels": ["Zoutgehalte verminderen", "Suikergehalte verlagen", "Vetgehalte beperken", "E-nummers vermijden"],
"explanation": "Consumer concerns about specific nutritional content and additives in ready-made meals"
},
{
"label": "Product diversiteit en keuze",
"topic_labels": ["Vegetarische opties uitbreiden", "Veganistische varianten", "Internationale keukens", "Seizoensgebonden menu's"],
"explanation": "Consumer demand for wider variety in meal types and dietary options"
}
// ... 5-8 themes total covering ALL topics ...
],
"topic_to_theme_mapping": {
"Zoutgehalte verminderen": "Nutritionele samenstelling",
"Suikergehalte verlagen": "Nutritionele samenstelling",
// ... mapping for ALL topics ...
}
}

Language: {language}

Input topics to group:
{topics}
"""

HIERARCHICAL_THEME_SUMMARY_PROMPT = """
You are a {language} expert in analyzing a theme derived from survey responses to the question:
"{var_lab}"

Theme: {theme_label}

Structure:
{theme_structure}

TASK:
- Write an analytical summary of this theme. Your goal is to explain what the theme reveals about how respondents interpret or experience the issue.

FOCUS:
- What dimension of the research question does this theme address?
- What are the key ideas, concerns, or viewpoints expressed?
- How do the topics within this theme offer different perspectives or nuances?
- What are the implications for interpreting the overall dataset?

OUTPUT FORMAT:
Return a JSON object with the following structure:

{
"summary": "This theme highlights respondents' shared focus on improving the physical composition of ready-made meals, particularly around portion sizes and ingredient quality. Topics within this theme show nuanced differences, from requests for larger portions to demands for fresher ingredients. Collectively, they reveal that consumers want more control over meal composition and higher quality standards.",
"relevance": "This theme explains how respondents want producers to fundamentally change what goes into meals and how much is provided."
}

Language: {language}
"""

# MapReduce prompts for hierarchical labeller
BATCH_SUMMARY_PROMPT = """
You are a qualitative researcher performing thematic analysis.

You are given a batch of micro-clusters (each cluster contains ~3-5 short statements with similar meaning). Your task is to analyze this batch and produce a hierarchical code structure.

**Instructions:**
- Identify Level 1 nodes (broad themes), Level 2 nodes (specific subthemes), and link each micro-cluster (Level 3) to its appropriate location.
- Each node name must be no more than 4 words and semantically clear.
- Do not rely on external knowledge — use only the given text.
- Maintain semantic integrity: use only the meanings in the micro-cluster texts.

**Output format:**
Return a JSON object with this exact structure:
{{
  "batch_id": "{batch_id}",
  "hierarchy": {{
    "1": {{
      "node": "Theme Name",
      "subthemes": {{
        "1.1": {{
          "node": "Subtheme Name",
          "micro_clusters": [0, 1]
        }},
        "1.2": {{
          "node": "Another Subtheme",
          "micro_clusters": [2]
        }}
      }}
    }},
    "2": {{
      "node": "Another Theme",
      "subthemes": {{
        "2.1": {{
          "node": "Subtheme Name",
          "micro_clusters": [3, 4]
        }}
      }}
    }}
  }}
}}

Variable label/context: {var_lab}
Language: {language}
Batch ID: {batch_id}

Micro-cluster batch:
{batch_clusters}
"""

REDUCE_SUMMARY_PROMPT = """
You are a qualitative researcher merging thematic structures from multiple batches into one unified codebook.

Each structure contains a partial thematic hierarchy with Level 1 and Level 2 codes. Your task is to synthesize these into a single consistent hierarchy.

**Instructions:**
- Merge similar themes and subthemes where meanings clearly overlap.
- Ensure Level 1 and Level 2 themes are **mutually exclusive**, **concise**, and **clearly distinguishable**.
- Each node name must be no more than 4 words.
- Adjust theme labels if needed to clarify differences.
- Reassign Level 1 and Level 2 numbers to maintain proper hierarchy.
- Preserve all micro-cluster assignments.

**Output format:**
Return a JSON object with this structure:
{{
  "unified_hierarchy": {{
    "1": {{
      "node": "Unified Theme Name",
      "subthemes": {{
        "1.1": {{
          "node": "Subtheme Name",
          "micro_clusters": [0, 1, 9]
        }},
        "1.2": {{
          "node": "Another Subtheme",
          "micro_clusters": [2, 15]
        }}
      }}
    }},
    "2": {{
      "node": "Another Theme",
      "subthemes": {{
        "2.1": {{
          "node": "Subtheme Name",
          "micro_clusters": [3, 4, 10]
        }}
      }}
    }}
  }}
}}

Variable label/context: {var_lab}
Language: {language}

Input hierarchies to merge:
{summaries}
"""

HIERARCHICAL_LABELING_PROMPT = """
You are finalizing a hierarchical codebook for thematic analysis based on qualitative data.

You are given:
- A consolidated hierarchical structure from previous analysis
- A list of all original micro-clusters for reference

Your task is to:
- Refine all node labels at Level 1 and Level 2 to make them mutually exclusive and unambiguous
- Ensure all labels reflect the intent of the underlying micro-cluster data
- Each node name must be no more than 4 words
- Align labels with the research context: {var_lab}
- Make sure no cluster is ambiguously assigned
- Verify complete coverage of all micro-clusters

**Output format:**
Return a cleaned-up hierarchical structure in this exact JSON format:
{{
  "themes": [
    {{
      "id": "1",
      "name": "Final Theme",
      "description": "Brief description of this theme",
      "topics": [
        {{
          "id": "1.1",
          "name": "Refined Subtheme",
          "description": "Brief description of this topic",
          "micro_clusters": [2, 4]
        }},
        {{
          "id": "1.2",
          "name": "Another Subtheme",
          "description": "Brief description",
          "micro_clusters": [7, 12]
        }}
      ]
    }},
    {{
      "id": "2",
      "name": "Another Theme",
      "description": "Theme description",
      "topics": [
        {{
          "id": "2.1",
          "name": "Subtheme Name",
          "description": "Topic description",
          "micro_clusters": [0, 3, 8]
        }}
      ]
    }}
  ]
}}

Language: {language}

Consolidated hierarchy:
{final_summary}

All micro-clusters for reference:
{micro_cluster_list}
"""


